# Uso de GitHub en la práctica docente
## Práctica 3.2
Repositorio de prácticas para la sesión 3 del curso

Incluye a continuación tu nombre y apellidos:
Cathaysa Navarro Benítez